# Kafka Security
Setup and configure Security functionality in Kafka.  
This repo uses OpenSource Apache Kafka deployed on EC2 (AWS).  

[goto setup Kafka](./Setup-Kafka)

[goto setup Kerberos](./Setup-Kerberos)

[goto setup SSL](./Setup-SSL)

