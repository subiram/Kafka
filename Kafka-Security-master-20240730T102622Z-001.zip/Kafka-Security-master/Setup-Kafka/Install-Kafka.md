# Installation of Apache Kafka
## install Kafka package
ssh into your EC2 instance
```
sudo apt-get update
sudo apt-get install -y wget net-tools  tar openjdk-11-jdk vim
wget https://downloads.apache.org/kafka/3.7.1/kafka_2.13-3.7.1.tgz
tar -xzf kafka_2.13-3.7.1.tgz
ln -s kafka_2.13-3.7.1 kafka
java -version
```
## start Zookeeper
ssh into your EC2 instance  
start zookeeper
```
~/kafka/bin/zookeeper-server-start.sh -daemon ~/kafka/config/zookeeper.properties
```
check if zookeeper is running
```
tail -n 5 ~/kafka/logs/zookeeper.out

echo "ruok" | nc localhost 2181 ; echo
```

## start Kafka
ssh into your EC2 instance
Start Kafka Broker
```
~/kafka/bin/kafka-server-start.sh -daemon ~/kafka/config/server.properties
```
Check Broker status
```
tail -n 10 ~/kafka/logs/kafkaServer.out
netstat -pant | grep ":9092"
```
