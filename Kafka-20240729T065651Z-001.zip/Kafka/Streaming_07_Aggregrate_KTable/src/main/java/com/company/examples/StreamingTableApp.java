package com.company.examples;

import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.KTable;
import org.apache.kafka.streams.kstream.Materialized;
import org.apache.kafka.streams.kstream.Printed;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Properties;

public class StreamingTableApp {
    private static final Logger logger = LogManager.getLogger();

    public static void main(final String[] args) {

        final Properties props = new Properties();
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, AppConfigs.applicationID);
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, AppConfigs.bootstrapServers);
        props.put(StreamsConfig.STATE_DIR_CONFIG, AppConfigs.stateStoreLocation);
        props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
        props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass());

        StreamsBuilder streamsBuilder = new StreamsBuilder();

        KTable<String, String> KT0 = streamsBuilder.table(AppConfigs.topicName);//Second parameter to this Consumed...but we have already
        //defaults serdes

        KT0.toStream().print(Printed.<String, String>toSysOut().withLabel("KT0"));
        //We can also use foreach and peek method to print out the messages..KTable does not offer peek,foreach and
        //Print hence we are converting Ktable to Stream using .toStream() method
        // HDFCBANK:120
        // HDFCBANK:
        // HDFCBANK,null


        KTable<String, String> KT1 = KT0.filter((k, v) -> k.matches(AppConfigs.regExSymbol) && !v.isEmpty(),
            //To see delete operation, we must not pass the values for given key...that will be taken as EMPTY
            Materialized.as(AppConfigs.stateStoreName)); //if we don't provide this parameter, API will give me some internal STORE name
            //this is required in case if you want to work directly with your local store
        KT1.toStream().print(Printed.<String, String>toSysOut().withLabel("KT1"));
        //[KT0]: HDFCBANK, 150
        //[KT1]: HDFCBANK, 150
        //[KT0]: HDFCBANK,
        //[KT1]: HDFCBANK, null -> This trigger delete operation.

        KafkaStreams streams = new KafkaStreams(streamsBuilder.build(), props);

        //Query Server : We are adding REST API to query the local state store:-> localhost:7010
        QueryServer queryServer = new QueryServer(streams, AppConfigs.queryServerHost, AppConfigs.queryServerPort);
        streams.setStateListener((newState, oldState) -> {
            logger.info("State Changing to " + newState + " from " + oldState);
            queryServer.setActive(newState == KafkaStreams.State.RUNNING && oldState == KafkaStreams.State.REBALANCING);
        });
        // you can check the current status of your KTABLE using :: c
        streams.start();
        queryServer.start();

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            logger.info("Shutting down servers");
            queryServer.stop();
            streams.close();
        }));

    }
}
