#kafka-topics.sh --create --topic pos --bootstrap-server localhost:9092 --partitions 3 --replication-factor 3
#kafka-topics.sh --create --topic shipment --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1
#kafka-topics.sh --create --topic loyalty --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1
#kafka-topics.sh --create --topic hadoop-sink --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1

