package com.company.examples;

import com.examples.types.Notification;
import com.examples.types.PosInvoice;
import org.apache.kafka.streams.kstream.ValueTransformer;
import org.apache.kafka.streams.processor.ProcessorContext;
import org.apache.kafka.streams.state.KeyValueStore;

public class RewardsTransformer implements ValueTransformer<PosInvoice, Notification> {

    private KeyValueStore<String, Double> stateStore;

    // we need processorContext to get the stateStore
    // init will be called once
    @Override
    public void init(ProcessorContext processorContext) {
        // Initialize state store defined above, to have local instance of state Store.
        this.stateStore = (KeyValueStore<String, Double>) processorContext.getStateStore(AppConfigs.REWARD_STORE_NAME);
    }

    //transform will be called once for each kafka message in the stream and message value is given

    @Override
    public Notification transform(PosInvoice posInvoice) {
        Notification notification = new Notification()
                .withInvoiceNumber(posInvoice.getInvoiceNumber())
                .withCustomerCardNo(posInvoice.getCustomerCardNo())
                .withTotalAmount(posInvoice.getTotalAmount())
                .withEarnedLoyaltyPoints(posInvoice.getTotalAmount() * AppConfigs.LOYALTY_FACTOR)
                .withTotalLoyaltyPoints(0.0);

        //Getting accumulated rewards for customers specific card no
        Double accumulatedRewards = stateStore.get(notification.getCustomerCardNo());

        Double totalRewards ;

        //If there are some accumulated point , Add new earned point ELSE proceed with earned point to start with 0.0
        if(accumulatedRewards !=null)
            totalRewards =accumulatedRewards + notification.getEarnedLoyaltyPoints();
        else
            totalRewards =notification.getEarnedLoyaltyPoints();

        stateStore.put(notification.getCustomerCardNo(),totalRewards);

        notification.setTotalLoyaltyPoints(totalRewards);

        return notification;
    }

    @Override
    public void close() {

    }
}
