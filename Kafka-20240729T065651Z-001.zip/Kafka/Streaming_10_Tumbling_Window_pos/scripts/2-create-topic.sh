kafka-topics.sh --create --bootstrap-server localhost:9092 --replication-factor 3 --partitions 3 --topic simple-invoice
# kafka-topics.sh --list  --bootstrap-server localhost:9092
#kafka-topics.sh --delete --bootstrap-server localhost:9092 --topic simple-invoice
# kafka-topics.sh --delete --bootstrap-server localhost:9092 --topic CountingWindowApp-KSTREAM-AGGREGATE-STATE-STORE-0000000001-changelog