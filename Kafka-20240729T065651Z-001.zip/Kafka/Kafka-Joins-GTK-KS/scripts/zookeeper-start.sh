zookeeper-server-start.sh $HOME/kafka/config/zookeeper.properties

