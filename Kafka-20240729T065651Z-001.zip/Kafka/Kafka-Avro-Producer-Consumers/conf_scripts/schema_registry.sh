/home/labuser/confluent/bin/schema-registry-start /home/labuser/confluent/etc/schema-registry/schema-registry.properties
