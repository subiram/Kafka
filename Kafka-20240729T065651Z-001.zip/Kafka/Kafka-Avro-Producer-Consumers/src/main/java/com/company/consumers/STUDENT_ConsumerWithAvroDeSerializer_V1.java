package com.company.consumers;


import com.company.avro.cust;
import io.confluent.kafka.serializers.KafkaAvroDeserializerConfig;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import java.util.Arrays;
import java.util.Properties;

public class STUDENT_ConsumerWithAvroDeSerializer_V1
{
    public static void main(String[] args)
    {
        Properties props = new Properties();
        props.put("bootstrap.servers", "localhost:9092");
        props.put("group.id", "grp-v1");
        props.put("auto.offset.reset", "earliest");

        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        props.put("auto.commit.interval.ms", "1000");
        props.put("session.timeout.ms", "7000");

        props.put("key.deserializer", "io.confluent.kafka.serializers.KafkaAvroDeserializer");
        props.put("value.deserializer", "io.confluent.kafka.serializers.KafkaAvroDeserializer");
        props.put("schema.registry.url", "http://localhost:8081");

        props.put(KafkaAvroDeserializerConfig.SPECIFIC_AVRO_READER_CONFIG, true);

        KafkaConsumer<String, cust> consumer = new KafkaConsumer<>(props);

        consumer.subscribe(Arrays.asList("cust_avro"));
        while (true)
        {
            ConsumerRecords<String, cust> records = consumer.poll(1000);
            for (ConsumerRecord<String, cust> record : records)
            {
                cust s = record.value();
                System.out.println("Customer record -> [CID: "+ s.getCid() + ", first_Name: " + s.getFname() + ", email: " + s.getEmailAddress()+ "]");

            }
        }
    }
}
