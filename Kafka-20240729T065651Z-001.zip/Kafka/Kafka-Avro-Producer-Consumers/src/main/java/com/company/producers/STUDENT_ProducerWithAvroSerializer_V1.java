package com.company.producers;


import com.company.avro.cust;
import org.apache.kafka.clients.producer.*;

import java.util.Properties;

public class STUDENT_ProducerWithAvroSerializer_V1 {
    public static void main(String[] args) throws InterruptedException {
        Properties props = new Properties();
        props.put("bootstrap.servers", "localhost:9092");
        props.put("acks", "1");  //"0" -No ack, "1" only Leader ,"all" ALL
        props.put("retries", 0);  // "0" doesn't re try ; positive value will retry
        props.put("key.serializer", "io.confluent.kafka.serializers.KafkaAvroSerializer");
        props.put("value.serializer", "io.confluent.kafka.serializers.KafkaAvroSerializer");
        props.put("schema.registry.url", "http://localhost:8081");

        Producer<String, cust> producer = new KafkaProducer<>(props);

        cust s = new cust("c1", "Vishal" , "patil",19,"vishal@abcd.com");
        ProducerRecord<String, cust> record = new ProducerRecord<>("cust_avro", "my-key_" + s.getCid(), s);
        producer.send(record);

        producer.close();
        System.out.println("message published");
    }
}