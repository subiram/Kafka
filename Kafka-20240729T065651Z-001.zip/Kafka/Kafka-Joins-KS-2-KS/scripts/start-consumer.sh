kafka-console-consumer --bootstrap-server localhost:9092 --topic pos --from-beginning
