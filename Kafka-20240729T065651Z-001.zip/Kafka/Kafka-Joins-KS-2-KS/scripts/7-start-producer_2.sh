kafka-console-producer.sh --bootstrap-server localhost:9092 --topic payment-confirmation --property parse.key=true --property key.separator=":"
