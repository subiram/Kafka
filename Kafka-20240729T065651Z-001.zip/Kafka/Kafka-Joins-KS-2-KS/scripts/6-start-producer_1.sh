kafka-console-producer.sh --bootstrap-server localhost:9092 --topic payment-request --property parse.key=true --property key.separator=":"
