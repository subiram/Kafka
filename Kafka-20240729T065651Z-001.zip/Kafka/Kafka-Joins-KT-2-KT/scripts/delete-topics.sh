kafka-topics.sh --delete --bootstrap-server localhost:9092  --topic user-master
kafka-topics.sh --delete --bootstrap-server localhost:9092  --topic user-login