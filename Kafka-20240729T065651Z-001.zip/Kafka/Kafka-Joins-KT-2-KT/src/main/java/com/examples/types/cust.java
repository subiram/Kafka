
package com.examples.types;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "custID",
    "firstName",
    "lastName",
    "age",
    "desig"
})
public class cust {

    @JsonProperty("custID")
    private String custID;
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("age")
    private Integer age;
    @JsonProperty("desig")
    private String desig;

    @JsonProperty("custID")
    public String getCustID() {
        return custID;
    }

    @JsonProperty("custID")
    public void setCustID(String custID) {
        this.custID = custID;
    }

    public cust withCustID(String custID) {
        this.custID = custID;
        return this;
    }

    @JsonProperty("firstName")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public cust withFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    @JsonProperty("lastName")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("lastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public cust withLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    @JsonProperty("age")
    public Integer getAge() {
        return age;
    }

    @JsonProperty("age")
    public void setAge(Integer age) {
        this.age = age;
    }

    public cust withAge(Integer age) {
        this.age = age;
        return this;
    }

    @JsonProperty("desig")
    public String getDesig() {
        return desig;
    }

    @JsonProperty("desig")
    public void setDesig(String desig) {
        this.desig = desig;
    }

    public cust withDesig(String desig) {
        this.desig = desig;
        return this;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("custID", custID).append("firstName", firstName).append("lastName", lastName).append("age", age).append("desig", desig).toString();
    }

}
