package com.examples;

import com.examples.serde.AppSerdes;
import com.examples.serde.JsonSerializer;
import com.examples.types.*;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


import java.util.Properties;

public class CustTxnJoin {
    private static final Logger logger = LogManager.getLogger();

    public static void main(String[] args) {
        Properties props = new Properties();
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, AppConfigs.applicationID_cust_txn);
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, AppConfigs.bootstrapServers);
        props.put(StreamsConfig.STATE_DIR_CONFIG, AppConfigs.stateStoreName1);
        props.put(StreamsConfig.COMMIT_INTERVAL_MS_CONFIG, 0);

        StreamsBuilder streamsBuilder = new StreamsBuilder();
        KTable<String, cust> KT0 = streamsBuilder.table(AppConfigs.custTopic,
                Consumed.with(AppSerdes.String(), AppSerdes.cust())
        );

        KTable<String, txns> KT1 = streamsBuilder.table(AppConfigs.txnTopic,
                Consumed.with(AppSerdes.String(), AppSerdes.txn())
        );
        

        cust_txn t1;
        KTable<String,cust_txn> KT22 = KT0.join(KT1, (custData, txnData) -> {

            return new cust_txn()
                    .withCid(custData.getCustID())
                    .withFirstname(custData.getFirstName())
                    .withAmount(txnData.getAmount())
                    .withTxnId(txnData.getTxnId());

        });

      KT22.toStream().print(Printed.toSysOut());

        logger.info("Starting Stream...");
        KafkaStreams streams = new KafkaStreams(streamsBuilder.build(), props);
        streams.start();

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            logger.info("Stopping Streams...");
            streams.close();
        }));

    }
}

