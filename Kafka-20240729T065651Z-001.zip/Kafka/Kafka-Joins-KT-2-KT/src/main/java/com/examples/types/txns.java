
package com.examples.types;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "txn_id",
    "txn_dt",
    "cid",
    "amount",
    "prod_cat",
    "prod",
    "city",
    "state",
    "mode"
})
public class txns {

    @JsonProperty("txn_id")
    private String txnId;
    @JsonProperty("txn_dt")
    private String txnDt;
    @JsonProperty("cid")
    private String cid;
    @JsonProperty("amount")
    private Double amount;
    @JsonProperty("prod_cat")
    private String prodCat;
    @JsonProperty("prod")
    private String prod;
    @JsonProperty("city")
    private String city;
    @JsonProperty("state")
    private String state;
    @JsonProperty("mode")
    private String mode;

    @JsonProperty("txn_id")
    public String getTxnId() {
        return txnId;
    }

    @JsonProperty("txn_id")
    public void setTxnId(String txnId) {
        this.txnId = txnId;
    }

    public txns withTxnId(String txnId) {
        this.txnId = txnId;
        return this;
    }

    @JsonProperty("txn_dt")
    public String getTxnDt() {
        return txnDt;
    }

    @JsonProperty("txn_dt")
    public void setTxnDt(String txnDt) {
        this.txnDt = txnDt;
    }

    public txns withTxnDt(String txnDt) {
        this.txnDt = txnDt;
        return this;
    }

    @JsonProperty("cid")
    public String getCid() {
        return cid;
    }

    @JsonProperty("cid")
    public void setCid(String cid) {
        this.cid = cid;
    }

    public txns withCid(String cid) {
        this.cid = cid;
        return this;
    }

    @JsonProperty("amount")
    public Double getAmount() {
        return amount;
    }

    @JsonProperty("amount")
    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public txns withAmount(Double amount) {
        this.amount = amount;
        return this;
    }

    @JsonProperty("prod_cat")
    public String getProdCat() {
        return prodCat;
    }

    @JsonProperty("prod_cat")
    public void setProdCat(String prodCat) {
        this.prodCat = prodCat;
    }

    public txns withProdCat(String prodCat) {
        this.prodCat = prodCat;
        return this;
    }

    @JsonProperty("prod")
    public String getProd() {
        return prod;
    }

    @JsonProperty("prod")
    public void setProd(String prod) {
        this.prod = prod;
    }

    public txns withProd(String prod) {
        this.prod = prod;
        return this;
    }

    @JsonProperty("city")
    public String getCity() {
        return city;
    }

    @JsonProperty("city")
    public void setCity(String city) {
        this.city = city;
    }

    public txns withCity(String city) {
        this.city = city;
        return this;
    }

    @JsonProperty("state")
    public String getState() {
        return state;
    }

    @JsonProperty("state")
    public void setState(String state) {
        this.state = state;
    }

    public txns withState(String state) {
        this.state = state;
        return this;
    }

    @JsonProperty("mode")
    public String getMode() {
        return mode;
    }

    @JsonProperty("mode")
    public void setMode(String mode) {
        this.mode = mode;
    }

    public txns withMode(String mode) {
        this.mode = mode;
        return this;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("txnId", txnId).append("txnDt", txnDt).append("cid", cid).append("amount", amount).append("prodCat", prodCat).append("prod", prod).append("city", city).append("state", state).append("mode", mode).toString();
    }

}
