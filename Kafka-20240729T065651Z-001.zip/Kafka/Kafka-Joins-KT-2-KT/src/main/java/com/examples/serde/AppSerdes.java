package com.examples.serde;

import com.examples.types.*;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;

import java.util.HashMap;
import java.util.Map;

public class AppSerdes extends Serdes {

    static final class UserDetailsSerde extends WrapperSerde<UserDetails> {
        UserDetailsSerde() {
            super(new com.examples.serde.JsonSerializer<>(), new com.examples.serde.JsonDeserializer<>());
        }
    }

    public static Serde<UserDetails> UserDetails() {
        UserDetailsSerde serde = new UserDetailsSerde();

        Map<String, Object> serdeConfigs = new HashMap<>();
        serdeConfigs.put(com.examples.serde.JsonDeserializer.VALUE_CLASS_NAME_CONFIG, UserDetails.class);
        serde.configure(serdeConfigs, false);

        return serde;
    }



    static final class UserLoginSerde extends WrapperSerde<UserLogin> {
        UserLoginSerde() {
            super(new com.examples.serde.JsonSerializer<>(), new com.examples.serde.JsonDeserializer<>());
        }
    }

    public static Serde<UserLogin> UserLogin() {
        UserLoginSerde serde = new UserLoginSerde();

        Map<String, Object> serdeConfigs = new HashMap<>();
        serdeConfigs.put(com.examples.serde.JsonDeserializer.VALUE_CLASS_NAME_CONFIG, UserLogin.class);
        serde.configure(serdeConfigs, false);

        return serde;
    }

    static final class custSerde extends WrapperSerde<cust> {
        custSerde() {
            super(new com.examples.serde.JsonSerializer<>(), new com.examples.serde.JsonDeserializer<>());
        }
    }

    public static Serde<cust> cust() {
        custSerde serde = new custSerde();

        Map<String, Object> serdeConfigs = new HashMap<>();
        serdeConfigs.put(com.examples.serde.JsonDeserializer.VALUE_CLASS_NAME_CONFIG, cust.class);
        serde.configure(serdeConfigs, false);

        return serde;
    }

    static final class txnsSerde extends WrapperSerde<txns> {
        txnsSerde() {
            super(new com.examples.serde.JsonSerializer<>(), new com.examples.serde.JsonDeserializer<>());
        }
    }

    public static Serde<txns> txn() {
        txnsSerde serde = new txnsSerde();

        Map<String, Object> serdeConfigs = new HashMap<>();
        serdeConfigs.put(com.examples.serde.JsonDeserializer.VALUE_CLASS_NAME_CONFIG, txns.class);
        serde.configure(serdeConfigs, false);

        return serde;
    }

    static final class cust_txnSerde extends WrapperSerde<cust_txn> {
        cust_txnSerde() {
            super(new com.examples.serde.JsonSerializer<>(), new com.examples.serde.JsonDeserializer<>());
        }
    }

    public static Serde<cust_txn> cust_txn() {
        cust_txnSerde serde = new cust_txnSerde();

        Map<String, Object> serdeConfigs = new HashMap<>();
        serdeConfigs.put(com.examples.serde.JsonDeserializer.VALUE_CLASS_NAME_CONFIG, cust_txn.class);
        serde.configure(serdeConfigs, false);

        return serde;
    }
}
