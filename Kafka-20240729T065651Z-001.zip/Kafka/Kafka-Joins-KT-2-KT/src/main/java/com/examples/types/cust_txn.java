
package com.examples.types;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "txn_id",
    "cid",
    "firstname",
    "amount"
})
public class cust_txn {

    @JsonProperty("txn_id")
    private String txnId;
    @JsonProperty("cid")
    private String cid;
    @JsonProperty("firstname")
    private String firstname;
    @JsonProperty("amount")
    private Double amount;

    @JsonProperty("txn_id")
    public String getTxnId() {
        return txnId;
    }

    @JsonProperty("txn_id")
    public void setTxnId(String txnId) {
        this.txnId = txnId;
    }

    public cust_txn withTxnId(String txnId) {
        this.txnId = txnId;
        return this;
    }

    @JsonProperty("cid")
    public String getCid() {
        return cid;
    }

    @JsonProperty("cid")
    public void setCid(String cid) {
        this.cid = cid;
    }

    public cust_txn withCid(String cid) {
        this.cid = cid;
        return this;
    }

    @JsonProperty("firstname")
    public String getFirstname() {
        return firstname;
    }

    @JsonProperty("firstname")
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public cust_txn withFirstname(String firstname) {
        this.firstname = firstname;
        return this;
    }

    @JsonProperty("amount")
    public Double getAmount() {
        return amount;
    }

    @JsonProperty("amount")
    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public cust_txn withAmount(Double amount) {
        this.amount = amount;
        return this;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("txnId", txnId).append("cid", cid).append("firstname", firstname).append("amount", amount).toString();
    }

}
