package com.company.examples;

import com.company.examples.serde.AppSerdes;
import com.company.examples.types.PosInvoice;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.*;
import org.apache.kafka.streams.state.StoreBuilder;
import org.apache.kafka.streams.state.Stores;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Properties;

public class RewardsApp {
    private static final Logger logger = LogManager.getLogger();

    public static void main(String[] args) {
        Properties props = new Properties();
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, AppConfigs.applicationID);
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, AppConfigs.bootstrapServers);
        props.put(StreamsConfig.NUM_STREAM_THREADS_CONFIG, 3);

        StreamsBuilder builder = new StreamsBuilder();

        KStream<String, PosInvoice> KS0 = builder.stream(
            AppConfigs.posTopicName,
            Consumed.with(AppSerdes.String(), AppSerdes.PosInvoice())
        ).filter((key, value) ->
            value.getCustomerType().equalsIgnoreCase(AppConfigs.CUSTOMER_TYPE_PRIME));


        //Creating StoreBuilder
        //https://kafka.apache.org/23/javadoc/index.html?org/apache/kafka/streams/package-summary.html
  ;      StoreBuilder kvStoreBuilder = Stores.keyValueStoreBuilder(
                Stores.inMemoryKeyValueStore(AppConfigs.REWARDS_STORE_NAME), //Store Supplier 1. In Memory ands 2. inPersistent - KV,Windows and Session..total 6
                AppSerdes.String(),
                AppSerdes.Double()
        );

        //Adding store to  Topology
        builder.addStateStore(kvStoreBuilder);

        //Java 7.0
        //KS0.transformValues(new ValueTransformerSupplier<PosInvoice, Notification>() {
        //  @Override
        //  public ValueTransformer<PosInvoice, Notification> get() {
        //          return null;
        //  }
        //  });
        // get() is not argument method ..Same code we can write using java 8.0 Lambda Functions


	//Write code to Use KS0.through processor :
 

        logger.info("Starting Stream");
        KafkaStreams stream = new KafkaStreams(builder.build(), props);
        stream.start();

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            logger.info("Stopping Streams");
            stream.cleanUp();
        }));
    }
}
