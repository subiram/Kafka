package com.company;


import com.company.avro.Student;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

import java.util.Properties;

public class STUDENT_ProducerWithAvroSerializerV2 {
    public static void main(String[] args) throws InterruptedException {
        Properties props = new Properties();
        props.put("bootstrap.servers", "localhost:9092");
        props.put("acks", "1");  //"0" -No ack, "1" only Leader ,"all" ALL
        props.put("retries", 0);  // "0" doesn't re try ; positive value will retry
        props.put("key.serializer", "io.confluent.kafka.serializers.KafkaAvroSerializer");
        props.put("value.serializer", "io.confluent.kafka.serializers.KafkaAvroSerializer");
        props.put("schema.registry.url", "http://localhost:8081");

        Producer<String, Student> producer = new KafkaProducer<>(props);
            Student s = new Student(1, "Sagar from v2","sagar"+"@abcd.com","90909090");
            ProducerRecord<String, Student> record = new ProducerRecord<>("student-record", "my-key" , s);
            producer.send(record);


        producer.close();
        System.out.println("message published");
    }
}