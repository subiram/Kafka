package com.company.examples;

class AppConfigs {
    final static String applicationID = "HelloStreams";
    final static String producerApplicationID = "HelloProducer";
    final static String bootstrapServers = "localhost:9092";
    final static String topicName = "hello-producer-stream";
    final static int numEvents = 20;
}
