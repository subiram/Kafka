package com.company.examples;

import com.company.examples.types.SimpleInvoice;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.streams.processor.TimestampExtractor;

import java.time.Instant;

public class InvoiceTimeExtractor implements TimestampExtractor {
    //The extract method  is invoked by the framework and given a ConsumerRecords
    //We also receive the timestamp of the prev message
    //We need to extract the timestamp from the consumer record VALUE and return it


    @Override
    public long extract(ConsumerRecord<Object, Object> consumerRecord, long prevTime) {
        //let extract invoice from the consumer record
        SimpleInvoice invoice = (SimpleInvoice) consumerRecord.value();

        //we will extract the created-time as epoch Milleseconds
        long eventTime = Instant.parse(invoice.getCreatedTime()).toEpochMilli();
        //Checking timestamp for the non-negative value
        return ((eventTime>0) ? eventTime : prevTime);
    }
}
