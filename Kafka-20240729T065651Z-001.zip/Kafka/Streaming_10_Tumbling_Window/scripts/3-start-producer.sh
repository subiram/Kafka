kafka-console-producer.sh --bootstrap-server localhost:9092 --topic simple-invoice --property parse.key=true --property key.separator=":"
